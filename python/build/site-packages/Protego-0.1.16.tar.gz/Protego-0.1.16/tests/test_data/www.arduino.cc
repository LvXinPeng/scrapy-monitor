User-agent: *
Disallow: /*action=edit
Disallow: /*action=diff
Disallow: /*action=print$
Disallow: /*action=upload
Disallow: /*action=login$
Disallow: /*action=logout$
Disallow: /*action=sourceblock
