User-Agent: *
Disallow: /mim/wspolne
Disallow: /mim/public/socialnet/
Disallow: /mim/socialnet/
Disallow: /mim/print-view/
Disallow: /tilecache/
Disallow: /mapa_geopoz/
